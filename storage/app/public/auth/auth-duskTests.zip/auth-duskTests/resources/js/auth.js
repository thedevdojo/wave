

function hello(){
    return 1+1;
}

function helloworld2(){
    return 'hello';
}

helloworld2();

