<?php

dataset('urls', [
    '/auth/login',
    '/auth/register',
    '/auth/verify',
    '/auth/password/reset',
    '/auth/password/confirm',
    '/auth/password/SomeReallyLongtoken',
]);
