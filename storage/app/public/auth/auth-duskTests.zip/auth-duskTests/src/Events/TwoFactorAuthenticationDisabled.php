<?php

namespace Devdojo\Auth\Events;

class TwoFactorAuthenticationDisabled extends TwoFactorAuthenticationEvent
{
    //
}
