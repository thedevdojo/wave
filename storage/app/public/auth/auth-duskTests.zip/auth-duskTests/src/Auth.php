<?php

namespace Devdojo\Auth;

class Auth
{
    // Build your next great package.
}
