<x-layouts.app>
	<div class="flex flex-col flex-1 items-stretch p-5 h-100">
		<div class="flex flex-col flex-1 items-stretch mx-auto w-full h-100">
			<div class="relative flex-1 w-full h-100">
				<x-placeholder class="h-100" />
			</div>
		</div>
	</div>
</x-layouts.app>