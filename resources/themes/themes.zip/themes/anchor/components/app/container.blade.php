<section {{ $attributes->twMerge('py-5 sm:py-8 lg:py-10 mx-auto w-full max-w-4xl') }}>
    {{ $slot }}
</section>