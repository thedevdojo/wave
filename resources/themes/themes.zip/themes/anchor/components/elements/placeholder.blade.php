<div class="absolute inset-0 h-full">
    <div class="overflow-hidden relative h-full border border-zinc-400 border-dashed opacity-75 dark:border-zinc-700 sm:rounded-xl">
        <svg class="absolute inset-0 w-full h-full stroke-zinc-900/10 dark:stroke-zinc-200/10" fill="none">
        <defs>
            <pattern id="pattern-b55d3ce5-d478-4029-95b9-44c415d04f63" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
            <path d="M-3 13 15-5M-5 5l18-18M-1 21 17 3"></path>
            </pattern>
        </defs>
        <rect stroke="none" fill="url(#pattern-b55d3ce5-d478-4029-95b9-44c415d04f63)" width="100%" height="100%"></rect>
        </svg>
    </div>
</div>