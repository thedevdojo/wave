<x-filament::link
    {{ $attributes }}
>
    {{ $slot }}
</x-filament::link>