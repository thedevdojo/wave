<label>
    <x-filament::input.checkbox {{ $attributes }} />
 
    <span>
        {{ $slot }}
    </span>
</label>