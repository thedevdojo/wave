<div {{ $attributes->twMerge('px-7 mx-auto max-w-7xl md:px-12 xl:px-20') }}>
    {{ $slot }}
</div>