<div {{ $attributes->twMerge('bg-white dark:bg-zinc-800 border-0 lg:border lg:p-8 rounded-lg relative lg:border h-auto w-full dark:border-zinc-700 border-zinc-200/50') }}>
    {{ $slot }}
</div>