<div {{ $attributes->merge(['class' => 'px-5 mx-auto max-w-7xl md:px-8']) }}>
    {{ $slot }}
</div>