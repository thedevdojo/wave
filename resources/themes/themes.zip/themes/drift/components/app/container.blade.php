<div {{ $attributes->merge(['class' => 'relative px-4 mx-auto max-w-7xl md:px-8']) }}">
    {{ $slot }}
</div>