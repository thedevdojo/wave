<div {{ $attributes->merge(['class' => 'relative w-full p-5 overflow-hidden bg-white border border-gray-200 shadow-sm dark:text-gray-400 dark:bg-gray-900 dark:border-gray-800 rounded-xl']) }}>
    {{ $slot }}
</div>